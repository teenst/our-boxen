# Evernote Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-evernote.png?branch=master)](https://travis-ci.org/boxen/puppet-evernote)

## Usage

```puppet
include evernote
```

## Required Puppet Modules

* boxen

